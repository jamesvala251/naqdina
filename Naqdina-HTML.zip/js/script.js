$(document).ready(function(){
    $('.openSitebararea').click(function(){
        $('#navSidebar').toggleClass('opensidebar');
        $('#main').toggleClass('mainboxarea');
    });
});